## 1. Application Details
|               |
| ------------- |
|**Template Used**<br>List Report Object Page V4|
|**Service Type**<br>OData Url|
|**Service URL**<br>https://ldai7er9.wdf.sap.corp:44300/sap/opu/odata4/sap/zdz_psc_c_sor_fes_srv/srvd/sap/zdz_psc_c_sor_frmextsrc_sd/0001/|
|**Main Entity**<br>SalesOrderRequest|
|**Navigation Entity**<br>_Item|
|**Module Name**<br>cus.sd.so.create.auto.xtrctns1|
|**Application Title**<br>Create Sales Orders - Automatic Extraction|
|**Namespace**<br>sor|
|**UI5 Theme**<br>sap_fiori_3|
|**UI5 Version**<br>Latest |
|**Enable Telemetry**<br>True |

## 2. cus.sd.so.create.auto.xtrctns1

Create Sales Orders - Automatic Extraction

### 2.1 Pre-requisites:

1. Install [Nodejs](https://nodejs.org) in your PC
2. Run `npm install` in the project folder


### 2.2 Start the app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```