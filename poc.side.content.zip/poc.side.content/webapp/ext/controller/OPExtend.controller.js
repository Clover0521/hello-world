sap.ui.define([
	"sap/ui/core/mvc/ControllerExtension",
	"sap/m/MessageToast"
], function (
	ControllerExtension,
	MessageToast
) {
	"use strict";
	return ControllerExtension.extend("cus.sd.so.create.auto.xtrctns1.ext.controller.LRExtend", {
		
		// this section allows to extend lifecycle hooks or override public methods of the base controller
		override: {
			extension: {},
			
			// Provide own onInit which is executed after the original onInit
			onInit: function () {},
			
			// Try to replace a private method tagged as not final -> This is currently not allowed
			onPageReady: function () {}
		}
	});
});