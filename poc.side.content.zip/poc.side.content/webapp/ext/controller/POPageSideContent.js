sap.ui.define([
	"sap/m/Image",
	"sap/m/MessageToast",
	"cus/sd/so/create/auto/xtrctns1/ext/container/ImageContainer"
], function(Image, MessageToast, ImageContainer) {
	"use strict";
	
	var bShowSideContent = false;

	return {
		toggleButtonShowHide: function(oEvent) {
			var oBindingContext = oEvent.getSource().getBindingContext();
			this.toggleCustomSectionSideContent(oBindingContext);
		},
		toggleHeaderDataSideContent: function(oEvent) {
			MessageToast.show("Click button in HeaderData section!");
			var that = this;
			if (bShowSideContent) {
				that.showSideContent("HeaderData");
				bShowSideContent = false;
			} else {
				var oCarousel = this.byId("cus.sd.so.create.auto.xtrctns1::SalesOrderRequestObjectPage--fe::SideContent::HeaderData--POPageCarousel");
	  			var oModel = this._view.getModel();
	  			var oList = oModel.bindList(oEvent.sPath + "/_Page");
	  			oList.requestContexts().then(function (aContexts) {
	  				oCarousel.removeAllPages();
				    aContexts.forEach(function (oContext) {
				    	// var sId = that._view.createId("ImageContainer-" + oContext.getObject().SalesOrderRequest + oContext.getIndex());
				    	var sSrc = "/sap/opu/odata4/sap/zdz_psc_c_sor_fes_srv/srvd/sap/zdz_psc_c_sor_frmextsrc_sd/0001" + oContext.getPath() + "/PurchaseOrderPageContentBinary";
				    	var oImageContainer = new ImageContainer({
				    		// id: sId,
				    		image: new Image({
				    			height: "100%",
	  							width: "100%",
	  							src: sSrc
				    		}) 
				    	});
				        oCarousel.addPage(oImageContainer);
				    });
				    that.showSideContent("HeaderData");
				    bShowSideContent = true;
				});
			}
		},
		toggleItemDatasSideContent: function(oEvent) {
			MessageToast.show("Click button in ItemDatas section!");
			this.showSideContent("ItemDatas");
		}
	};
});
