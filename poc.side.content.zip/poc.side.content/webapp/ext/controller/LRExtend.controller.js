sap.ui.define([
	"sap/ui/core/Fragment", 
	"sap/m/MessageBox", 
	"sap/ui/unified/FileUploader", 
	"sap/ui/model/json/JSONModel"
], function (Fragment, MessageBox, FileUploader, JSONModel) {
	"use strict";

	var that = {

		oNewRequestContext: null,

		/**
		 * Function invoked when pressing the create sales order request action
		 */
		onPressUploadFile: function (oEvent) {
			that.uploadDialogSource = this._view;
			that.oResourceBundle = that.uploadDialogSource.getModel("i18n").getResourceBundle();
			that.uploadRawReportDialogPromise = that.uploadRawReportDialogPromise || Fragment.load({
				id: "uploadReportRawDataDialog",
				name: "cus.sd.so.create.auto.xtrctns1.ext.Fragments.FileUploadDialog",
				controller: that
			});
			that.uploadRawReportDialogPromise.then(function (dialog) {
				that.uploadDialogSource.addDependent(dialog);
			});
			that.uploadRawReportDialogPromise.then(function (dialog) {
				dialog.open();
			});
		},
		
		onTypeMissMatch: function (oEvent) {
			MessageBox.error(that.oResourceBundle.getText("fileUpldVw_selecfPdfFile"));
		},

		onfileSizeExceed: function (oEvent) {
			MessageBox.error(that.oResourceBundle.getText("fileUpldVw_selecfPdfFile"));
		},
		
		onFilePathChange: function(oEvent){
		},
		
		uploadFile: function (oContext) {
			var oFileUploader = that.getObjectById("uploadReportRawDataDialog", "fileUploaderRawData");
			var aFiles = oFileUploader.getFocusDomRef().files;
			if (!aFiles || aFiles.length !== 1) {
				MessageBox.error(that.oResourceBundle.getText("fileUpldVw_selecfPdfFile"));
				return;
			}

			//busy
			var oDialog = that.getObjectById("uploadReportRawDataDialog", "dialogUploadFile");
			oDialog.setBusy(true);

			var sActionName = "com.sap.gateway.srvd.zdz_psc_c_sor_frmextsrc_sd.v0001.CreateSalesOrderRequest";

			var oListBinding = that.uploadDialogSource.getController().getTableBinding();

			var oModel = that.uploadDialogSource.getModel(),
				oAction = oModel.bindContext(sActionName + "(...)", oListBinding.getHeaderContext());

			oAction.setParameter("ResultIsActiveEntity", true);
			oAction.setParameter("SalesOrderRequestCategory", "A");

			oAction.execute().then(function (oContext) {
				that.oNewRequestContext = oContext;
				var oNewRequest = that.oNewRequestContext.getObject();

				var sFileUploadURL = "/sap/opu/odata4/sap/zdz_psc_c_sor_fes_srv/srvd/sap/zdz_psc_c_sor_frmextsrc_sd/0001/SalesOrderRequest(SalesOrderRequest='" + oNewRequest.SalesOrderRequest + "',IsActiveEntity=true)/UploadFileContentBinary";

				var headerParameterContentType = new sap.ui.unified.FileUploaderParameter();
				headerParameterContentType.setName('Content-Type');
				headerParameterContentType.setValue('application/pdf');
				oFileUploader.addHeaderParameter(headerParameterContentType);

				var csrfToken = oFileUploader.getModel().getHttpHeaders()["X-CSRF-Token"];
				var headerParameterCSRFToken = new sap.ui.unified.FileUploaderParameter();
				headerParameterCSRFToken.setName('x-csrf-token');
				headerParameterCSRFToken.setValue(csrfToken);
				oFileUploader.addHeaderParameter(headerParameterCSRFToken);

				oFileUploader.setUploadUrl(sFileUploadURL);
				oFileUploader.upload();

			}, function (sError) {
				oDialog.setBusy(false);
				//failed to create sales order via external source
				that.handleImportError(sError);
				// MessageBox.error(that.oResourceBundle.getText("fileUpldBiz_uploadFailed"));
			});
		},

		onUploadComplete: function (oEvent) {
			var oDialog = that.getObjectById("uploadReportRawDataDialog", "dialogUploadFile");
			//error handling
			var sStatus = oEvent.getParameter("status") + "";
			var oFileUploader = oEvent.getSource();
			//success
			if (sStatus[0] === '2') {
				oDialog.setBusy(false);
				oFileUploader.removeAllHeaderParameters();
				oFileUploader.clear();
				oDialog.close();
				that.uploadDialogSource.removeDependent(oDialog);
				//TODO Refresh list
				//sap.ui.getCore().byId("cus.sd.so.create.auto.xtrctns1::SalesOrderRequestList--fe::FilterBar::SalesOrderRequest-btnSearch").firePress();
				var oListBinding = that.uploadDialogSource.getController().getTableBinding();
				oListBinding.refresh();

			} else {
				var oModel = new JSONModel();
				oModel.attachRequestCompleted(function (oEvent) {
					oDialog.setBusy(false);
					if (oEvent.getParameter("success")) {
						// MessageBox.error(sUploadPdfFailedMsg);
						that.handleImportError(oEvent);
					}
				});
				oModel.attachRequestFailed(function (oEvent) {
					oDialog.setBusy(false);
					// MessageBox.error(sUploadPdfFailedMsg);
					that.handleImportError(oEvent);
				});
				var sUrl = "/sap/opu/odata4/sap/zdz_psc_c_sor_fes_srv/srvd/sap/zdz_psc_c_sor_frmextsrc_sd/0001/SalesOrderRequest(SalesOrderRequest='" + that.oNewRequestContext.getObject().SalesOrderRequest + "',IsActiveEntity=true)";
				oModel.loadData(
					sUrl,
					null,
					false,
					"DELETE",
					false,
					false, {
						"x-csrf-token": oFileUploader.getModel().getHttpHeaders()["X-CSRF-Token"],
						"Content-Type" : "application/json",
						"Accept": "application/json"
					}
				);
			}
			// Demo version only - we call the action immediately - later have to pull until the job is done
			// var oListBinding = that.uploadDialogSource.getController().getTableBinding();
			// var oModel = that.oNewRequestContext.getModel();
			// var sAdaptAction = "com.sap.gateway.srvd.c_slsordreqmanage_sd.v0001.AdoptFileContentAnalysis"
			// var oAdaptAction = oModel.bindContext(sAdaptAction + "(...)", oListBinding.getHeaderContext());
			// var oPropertyBinding = oModel.bindProperty("SalesOrderRequestExtractorUUID", that.oNewRequestContext);
			// that.oNewRequestContext.refresh();
			// oPropertyBinding.initialize();
			// oPropertyBinding.requestValue().then(function(sExtractorUUID){
			// 	// now trigger action to adapt sales order request
			// 	oAdaptAction.setParameter("SalesOrderRequestExtractorUUID", sExtractorUUID);
			// 	oAdaptAction.execute().then(function(){
			// 		MessageToast.show("New Sales Order Request updated");
			// 		// TODO:  Refresh list
			// 	})
			// });

		},

		onUploadCancel: function (oEvent) {
			var oFileUploader = that.getObjectById("uploadReportRawDataDialog", "fileUploaderRawData");
			oFileUploader.removeAllHeaderParameters();
			oFileUploader.clear();
			var oDialog = oEvent.getSource().getParent();
			oDialog.close();
			that.uploadDialogSource.removeDependent(oDialog);
		},
		
		handleImportError: function (oError) {
			var sErrorMessage = that.oResourceBundle.getText("fileUpldBiz_uploadFailed");
			try {
				var oErrorMessage = JSON.parse(oError.responseText);
			} catch (err) {
				MessageBox.error(sErrorMessage);
				return;
			}
			if (oErrorMessage.error && oErrorMessage.error.message && oErrorMessage.error.message.value) {
				MessageBox.error(sErrorMessage, {
					details: oErrorMessage.error.message.value
				});
			} else {
				MessageBox.error(sErrorMessage);
			}

		},
		
		getObjectById: function(sFragmentId, sElementId){
			return sap.ui.core.Fragment.byId(sFragmentId, sElementId);
		}
	};
	return that;
});