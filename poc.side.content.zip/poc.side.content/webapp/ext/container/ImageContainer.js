sap.ui.define([
	"sap/ui/core/Control"
], function (Control) {
	var ImageContainer = Control.extend("cus.sd.so.create.auto.xtrctns1.ext.container.ImageContainer", {
		metadata: {
			properties: {
				image: {
					type: "sap.m.Image"
				}
			}
		},

		renderer: function (oRm, oControl) {
			oRm.write("<div ");
			oRm.addStyle("position", "relative");
			oRm.writeStyles();
			oRm.writeControlData(oControl);
			oRm.write(">");
			oRm.write("<div ");
			oRm.addStyle("position", "relative");
			oRm.writeStyles();
			oRm.write(">");
			oRm.renderControl(oControl.getImage());
			//oRm.renderControl(oControl.getPdf());
			oRm.write("</div>");
			oRm.write("</div>");
		}
	});

	return ImageContainer;
});